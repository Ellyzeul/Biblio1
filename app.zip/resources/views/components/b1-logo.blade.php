<a href="/">
  <img id="logo" src="/assets/img/b1logo.gif" alt="Biblio1 - Busque títulos e compare preços">
</a>
