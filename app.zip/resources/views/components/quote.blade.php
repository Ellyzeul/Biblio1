<div id="quote">
	<p>
		<span>“</span>
		{{ $quote }}
		<span>”</span>
	</p>
	{{ $quote_author }}
</div>
