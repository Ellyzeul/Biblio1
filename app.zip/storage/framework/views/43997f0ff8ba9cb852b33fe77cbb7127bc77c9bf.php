<section class="result-list-item">
	<img class="result-list-item-cover" src="<?php echo e($thumbnail); ?>" alt="Capa do livro">
	<div>
		<div><span>Título:</span> <?php echo e($title); ?></div>
		<div><span>ISBN-13:</span> <?php echo e($isbn13); ?></div>
		<?php if(isset($isbn10)): ?><div><span>ISBN-10:</span> <?php echo e($isbn10); ?></div><?php endif; ?>
		<?php if(isset($publisher)): ?><div><span>Editora:</span> <?php echo e($publisher); ?></div><?php endif; ?>
	</div>
	<a href="/resultado?isbn=<?php echo e($isbn13); ?>"></a>
</section>
<?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/components/result-list-item.blade.php ENDPATH**/ ?>