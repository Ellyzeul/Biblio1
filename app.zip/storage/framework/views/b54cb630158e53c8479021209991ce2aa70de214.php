<nav id="navbar">
  
</nav>
<?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/components/navbar.blade.php ENDPATH**/ ?>