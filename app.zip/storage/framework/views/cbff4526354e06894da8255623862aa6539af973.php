<a class="cotation-row" href="<?php echo e($link); ?>" target="_blank">
  <img src="/assets/img/<?php echo e($idSellercentral); ?>.png" alt="">
  <div><?php if($company == "general"): ?><?php echo e($sellercentral); ?><?php else: ?><?php echo e($company); ?><?php endif; ?></div>
  <div>R$ <?php if(isset($price) && $price != "0.00"): ?><?php echo e(preg_replace("/\./", ",", $price)); ?><?php else: ?><?php echo e('----'); ?><?php endif; ?></div>
</a>
<?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/components/cotation-row.blade.php ENDPATH**/ ?>