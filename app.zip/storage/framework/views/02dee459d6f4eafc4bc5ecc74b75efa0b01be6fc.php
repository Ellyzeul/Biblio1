<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Google tag (gtag.js) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-20712069-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-20712069-1');
  </script>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="keywords" content="<?php echo e(implode(', ', $keywords)); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/assets/css/global.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('/assets/css/result.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/assets/css/components/navbar.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/assets/css/components/search_box.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/assets/css/components/quote.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('/assets/css/components/result_list.css')); ?>">
  <title><?php echo e($page_title); ?></title>
  <script src="<?php echo e(asset('/assets/js/components/search_box.js')); ?>" defer></script>
</head>
<body>
  <section id="result">
    <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
    <div id="result-content">
      <div id="seline-banner">
        <?php if($total == 1): ?>
          <a href="<?php echo e($seline_link); ?>">
            <img src="/assets/img/seline-banner.jpeg" alt="">
          </a>
        <?php endif; ?>
      </div>
      <div id="middle-container">
        <header id="result-topbar">
          <?php if (isset($component)) { $__componentOriginalee410713b93b526d9bd9718cc8ca65b7871f9726 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\B1Logo::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('b1-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\B1Logo::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee410713b93b526d9bd9718cc8ca65b7871f9726)): ?>
<?php $component = $__componentOriginalee410713b93b526d9bd9718cc8ca65b7871f9726; ?>
<?php unset($__componentOriginalee410713b93b526d9bd9718cc8ca65b7871f9726); ?>
<?php endif; ?>
          <div></div>
          <?php if (isset($component)) { $__componentOriginala07de961ad96bdff1abbbcd093fd6b4941ae6474 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SearchBox::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\SearchBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala07de961ad96bdff1abbbcd093fd6b4941ae6474)): ?>
<?php $component = $__componentOriginala07de961ad96bdff1abbbcd093fd6b4941ae6474; ?>
<?php unset($__componentOriginala07de961ad96bdff1abbbcd093fd6b4941ae6474); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginal849b79bfb0a50801c2d86c4acb7235497ec5cf8c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Quote::class, ['quote' => $quote,'quoteAuthor' => $quote_author] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('quote'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Quote::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal849b79bfb0a50801c2d86c4acb7235497ec5cf8c)): ?>
<?php $component = $__componentOriginal849b79bfb0a50801c2d86c4acb7235497ec5cf8c; ?>
<?php unset($__componentOriginal849b79bfb0a50801c2d86c4acb7235497ec5cf8c); ?>
<?php endif; ?>
          <hr>
        </header>
        <?php if($total > 1): ?>
          <?php if (isset($component)) { $__componentOriginal4763a1e364c24736f7ddc5d028b6a2dc0820c831 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ResultList::class, ['books' => $books] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('result-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ResultList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4763a1e364c24736f7ddc5d028b6a2dc0820c831)): ?>
<?php $component = $__componentOriginal4763a1e364c24736f7ddc5d028b6a2dc0820c831; ?>
<?php unset($__componentOriginal4763a1e364c24736f7ddc5d028b6a2dc0820c831); ?>
<?php endif; ?>
        <?php elseif($total == 1): ?>
          <?php if (isset($component)) { $__componentOriginal9e53282e88226bf96015e054ca4cfaf876f955f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ResultByIsbn::class, ['book' => $books[0],'links' => $links] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('result-by-isbn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ResultByIsbn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e53282e88226bf96015e054ca4cfaf876f955f3)): ?>
<?php $component = $__componentOriginal9e53282e88226bf96015e054ca4cfaf876f955f3; ?>
<?php unset($__componentOriginal9e53282e88226bf96015e054ca4cfaf876f955f3); ?>
<?php endif; ?>
        <?php else: ?>
          <div>Nenhum resultado para a pesquisa foi encontrado.</div>
        <?php endif; ?>
      </div>
    </div>
  </section>
</body>
</html><?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/result.blade.php ENDPATH**/ ?>