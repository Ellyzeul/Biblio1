<main id="isbn-result">
	<div id="isbn-result-cover-container">
		<img src="<?php echo e($thumbnail); ?>" alt="">
	</div>
	<section id="book-description">
		<p><span>Título:</span> <?php echo e($title); ?></p>
		<?php if(isset($author)): ?><p><span>Autor:</span> <?php echo e($author); ?></p><?php endif; ?>
		<?php if(isset($publisher)): ?><p><span>Editora:</span> <a href="/resultado?publisher=<?php echo e($publisher); ?>"><?php echo e($publisher); ?></a></p><?php endif; ?>
		<?php if(isset($isbn10)): ?><p><span>ISBN-10:</span> <?php echo e($isbn10); ?></p><?php endif; ?>
		<p><span>ISBN-13:</span> <?php echo e($isbn13); ?></p>
		<?php if(isset($description)): ?><p><span>Sinopse:</span> <?php echo e($description); ?></p><?php endif; ?>
	</section>
	<section id="cotation">
		<h2>Cotações para o livro</h2>
		<?php if(count($links) > 0): ?>
			<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if (isset($component)) { $__componentOriginale487a4cd4312586af591ce08df3345111b173829 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CotationRow::class, ['price' => $link['price'],'idSellercentral' => $link['id_sellercentral'],'sellercentral' => $link['sellercentral'],'company' => $link['company'],'idCompany' => $link['id_company'],'link' => $link['link']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cotation-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CotationRow::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale487a4cd4312586af591ce08df3345111b173829)): ?>
<?php $component = $__componentOriginale487a4cd4312586af591ce08df3345111b173829; ?>
<?php unset($__componentOriginale487a4cd4312586af591ce08df3345111b173829); ?>
<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
			<p id="no-cotation">Sem cotações para esse livro.</p>
		<?php endif; ?>
	</section>
	<div id="iframe-container">
		<script type="text/javascript" src="https://books.google.com/books/previewlib.js"></script>
		<script type="text/javascript">GBS_setLanguage('pt-BR')</script>
		<script type="text/javascript">
			const iframeContainer = document.querySelector("#iframe-container")
			const { width } = iframeContainer.getBoundingClientRect()
			GBS_insertEmbeddedViewer('ISBN:<?php echo e($isbn13); ?>', width, 900)
			const container = document.querySelector("#__GBS_Button0")
			window.addEventListener('resize', () => {
				if(!container.firstChild) return
				container.children[0].style.width = iframeContainer
					.getBoundingClientRect()
					.width + "px"
			})
		</script>
		<div id="iframe-overlay"></div>
	</div>
</main>
<?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/components/result-by-isbn.blade.php ENDPATH**/ ?>