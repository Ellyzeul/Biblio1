<a href="/">
  <img id="logo" src="/assets/img/b1logo.gif" alt="Biblio1 - Busque títulos e compare preços">
</a>
<?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/components/b1-logo.blade.php ENDPATH**/ ?>