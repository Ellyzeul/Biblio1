<main id="result-list">
	<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if (isset($component)) { $__componentOriginal1049703fabc76db015060edeca29686ba1ab5a41 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ResultListItem::class, ['isbn13' => $book->isbn13,'isbn10' => $book->isbn10,'title' => $book->title,'author' => $book->author,'publisher' => $book->publisher,'thumbnail' => $book->thumbnail,'description' => $book->description] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('result-list-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\ResultListItem::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1049703fabc76db015060edeca29686ba1ab5a41)): ?>
<?php $component = $__componentOriginal1049703fabc76db015060edeca29686ba1ab5a41; ?>
<?php unset($__componentOriginal1049703fabc76db015060edeca29686ba1ab5a41); ?>
<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main>
<?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/components/result-list.blade.php ENDPATH**/ ?>