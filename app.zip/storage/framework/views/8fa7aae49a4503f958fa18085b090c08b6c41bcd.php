<div id="quote">
	<p>
		<span>“</span>
		<?php echo e($quote); ?>

		<span>”</span>
	</p>
	<?php echo e($quote_author); ?>

</div>
<?php /**PATH C:\Users\LowCost\Projetos\Biblio1\resources\views/components/quote.blade.php ENDPATH**/ ?>